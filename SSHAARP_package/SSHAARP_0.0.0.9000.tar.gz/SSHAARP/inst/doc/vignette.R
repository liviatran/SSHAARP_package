## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- out.width='100%', fig.align='center', fig.cap='...'----------------
knitr::include_graphics("../images/basemap.jpg")

## ---- out.width='100%', fig.align='center', fig.cap='...'----------------
knitr::include_graphics("../images/basemap_BW.jpg")

